# IDVerse SDK Browser

## Overview

IDVerse SDK Browser is designed for document capturing and face recognition. It facilitates the identification and processing of various documents, such as driving licenses, passports, and visas, while also detecting and processing facial images. The SDK provides built-in UI components for a seamless integration, as well as a flexible API for custom implementations. It is built using modern web technologies like WebAssembly for high performance, and is suitable for web applications needing robust document and face recognition features.

## Documentation

The SDK documentation is available at [idvplatform.docs.idverse.com/docs/getting-started](https://idvplatform.docs.idverse.com/docs/getting-started).
